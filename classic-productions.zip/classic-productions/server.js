const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const { router: authRouter, requireAuth } = require('./routes/auth');
const publicRouter = require('./routes/public');
const adminRouter = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Public website static files
app.use(express.static(path.join(__dirname, 'public')));

// Public API (no auth) — for website forms
app.use('/api', publicRouter);

// Auth endpoints (login/logout)
app.use('/auth', authRouter);

// Admin login page — accessible without auth
app.get('/admin/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin', 'login.html'));
});

// All other /admin routes & API require auth
app.use('/admin/api', requireAuth, adminRouter);
app.use('/admin', requireAuth, express.static(path.join(__dirname, 'admin')));

// Fallback
app.use((req, res) => {
  res.status(404).send('Not found');
});

app.listen(PORT, () => {
  console.log(`\n🎵 Classic Productions running at http://localhost:${PORT}`);
  console.log(`   Public site:  http://localhost:${PORT}`);
  console.log(`   Admin CRM:    http://localhost:${PORT}/admin`);
  console.log(`   Login with:   ${process.env.ADMIN_USERNAME || 'admin'} / ${process.env.ADMIN_PASSWORD || 'admin123'}\n`);
});
