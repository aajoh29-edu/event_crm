const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const db = new Database(path.join(__dirname, 'classic.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

console.log('Creating tables...');

db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    vip_status INTEGER DEFAULT 0,
    notes TEXT,
    total_spent REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    genre TEXT,
    description TEXT,
    event_date DATE NOT NULL,
    event_time TEXT,
    venue TEXT,
    image_url TEXT,
    ticket_price REAL DEFAULT 0,
    capacity INTEGER DEFAULT 100,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    event_id INTEGER,
    quantity INTEGER DEFAULT 1,
    total_price REAL DEFAULT 0,
    status TEXT DEFAULT 'confirmed',
    booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (event_id) REFERENCES events(id)
  );

  CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    party_size INTEGER DEFAULT 2,
    reservation_date DATE NOT NULL,
    reservation_time TEXT,
    table_type TEXT DEFAULT 'standard',
    special_requests TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
  );

  CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'unread',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    active INTEGER DEFAULT 1
  );
`);

console.log('Tables created.');

// Seed admin user
const adminUsername = process.env.ADMIN_USERNAME || 'admin';
const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
const existingAdmin = db.prepare('SELECT id FROM admins WHERE username = ?').get(adminUsername);

if (!existingAdmin) {
  const hash = bcrypt.hashSync(adminPassword, 10);
  db.prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)').run(adminUsername, hash);
  console.log(`Admin created: ${adminUsername} / ${adminPassword}`);
} else {
  console.log('Admin already exists.');
}

// Seed events from the existing site
const eventCount = db.prepare('SELECT COUNT(*) as c FROM events').get().c;
if (eventCount === 0) {
  const insertEvent = db.prepare(`
    INSERT INTO events (title, genre, description, event_date, event_time, venue, image_url, ticket_price, capacity)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insertEvent.run(
    'Velvet Lounge Sessions',
    '90s R&B Classics',
    'Experience the smooth sounds of the golden era in an intimate setting.',
    '2026-10-15', '21:00', 'The Velvet Room',
    'https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?auto=format&fit=crop&w=600&q=80',
    75.00, 120
  );
  insertEvent.run(
    'The Penthouse Gala',
    'Modern Hip-Hop',
    "High-energy curation featuring the city's premier lyricists and DJs.",
    '2026-10-22', '22:00', 'Skyline Penthouse',
    'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=600&q=80',
    125.00, 200
  );
  insertEvent.run(
    'Midnight Manifesto',
    'Soul & Trap Fusion',
    'Where street culture meets luxury hospitality. Dress code strictly enforced.',
    '2026-11-05', '23:00', 'The Underground',
    'https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=600&q=80',
    95.00, 150
  );
  console.log('Seeded 3 events.');
}

// Seed sample customers for demo
const custCount = db.prepare('SELECT COUNT(*) as c FROM customers').get().c;
if (custCount === 0) {
  const ins = db.prepare(`INSERT INTO customers (first_name, last_name, email, phone, vip_status, total_spent) VALUES (?, ?, ?, ?, ?, ?)`);
  ins.run('Marcus', 'Johnson', 'marcus.j@example.com', '555-0101', 1, 450.00);
  ins.run('Aaliyah', 'Williams', 'aaliyah.w@example.com', '555-0102', 1, 875.00);
  ins.run('David', 'Chen', 'david.c@example.com', '555-0103', 0, 150.00);
  ins.run('Sofia', 'Martinez', 'sofia.m@example.com', '555-0104', 0, 95.00);
  console.log('Seeded 4 sample customers.');
}

console.log('\n✓ Database initialized at db/classic.db');
db.close();
